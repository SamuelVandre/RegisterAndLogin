using System;
namespace RegisterLogin;
public class Login
{
    public static string LoginUser(string user, string password)
    {
        Error.ErrorContent(ValueVars.name, ValueVars.password);
        if (Error.ExistError)
            return Error.ErrorMessage!;

        for (int i = 0; i < DataBase.Users.Length; i++)
            if ((DataBase.Users[i] == user) && (DataBase.Passwords[i] == password))
                return "Login efeituado com sucesso";

        return "Login não efetuado, verifique o usuário e a senha";

    }
}