using System;
namespace RegisterLogin;

public class ValueVars
{
    public static string? name = "Samuel";//está em letra minuscula pois só será uma prop após eu implementar um formulário para que isso vire uma propriedade
    public static string? password = "123";

}