﻿using System;
using RegisterLogin;

Console.WriteLine("Teste de Login: " + Login.LoginUser(ValueVars.name!, ValueVars.password!));
Console.WriteLine("Teste de cadastro: " + Register.UserRegister(ValueVars.name!, ValueVars.password!));