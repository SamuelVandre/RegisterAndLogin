using System;
class DataBase
{
    public static string?[] Users = { "Samuel", "João", "Carlos", };
    public static string?[] Passwords = { "123", "321", "231" };

}