using System;
namespace RegisterLogin;

class Register
{
    public Register(string? username, string? password)
    {
        UserReg = username;
        PasswordReg = password;
    }
    public static string? UserReg { get; set; }
    public static string? PasswordReg { get; set; }

    public static string UserRegister(string? username, string? password)
    {
        //var commandQuery = $"SELECT * FROM table WHERE user='{UserReg}'";
        //bool query = true;
        // if (query)
        //     return "Esse usuário já existe.";
        Error.ErrorContent(ValueVars.name, ValueVars.password);
        if (Error.ExistError)
            return Error.ErrorMessage!;

        for (int i = 0; i < DataBase.Users.Length; i++)
            if (ValueVars.name == DataBase.Users[i])
                return "Esse usuário já existe";

        return "Seu cadastro foi realizado";
    }
}