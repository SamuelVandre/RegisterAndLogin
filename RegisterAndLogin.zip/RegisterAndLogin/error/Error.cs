using System;
namespace RegisterLogin;
public class Error
{
    public static bool ExistError { get; set; } = true;
    public static string? ErrorMessage { get; set; }
    public static string ErrorContent(string? value1, string? value2)
    {
        if ((value1 == string.Empty) || (value2 == string.Empty) || (value1 == null) || (value2 == null))
        {
            ExistError = true;
            ErrorMessage = "Valor vazio ou invalido";
            return "Seu valor não pode ser vazio";
        }
        ExistError = false;
        return "Sla";
    }
}